# 教程

https://github.com/abhimishra91/pytorch-tutorials

git@github.com:abhimishra91/transformers-tutorials.git


The notebook will be divided into seperate sections to provide a organized walk through for the process used. This process can be modified for individual use cases. The sections are:

机器学习的流程
- Importing Python Libraries and preparing the environment
- Importing and Pre-Processing the domain data
- Preparing the Dataset and Dataloader
- Creating the Neural Network for Fine Tuning
- Fine Tuning the Model
- Validating the Model Performance
- Saving the model and artifacts for Inference in Future

文本分类字段名称:
Index(['id', 'comment_text', 'toxic', 'severe_toxic', 'obscene', 'threat',
       'insult', 'identity_hate', 'list'],
      dtype='object')

	comment_text	list
159566	":::::And for the second time of asking, when ...	[0, 0, 0, 0, 0, 0]
159567	You should be ashamed of yourself \n\nThat is ...	[0, 0, 0, 0, 0, 0]
159568	Spitzer \n\nUmm, theres no actual article for ...	[0, 0, 0, 0, 0, 0]
159569	And it looks like it was actually you who put ...	[0, 0, 0, 0, 0, 0]
159570	"\nAnd ... I really don't think you understand...	[0, 0, 0, 0, 0, 0]


為了讓你直觀了解 BERT 運作，本文使用包含繁體與簡體中文的預訓練模型。 你可以在 Hugging Face 團隊的 repo 裡看到所有可從 PyTorch Hub 載入的 BERT 預訓練模型。截至目前為止有以下模型可供使用：

- bert-base-chinese
- bert-base-uncased
- bert-base-cased
- bert-base-german-cased
- bert-base-multilingual-uncased
- bert-base-multilingual-cased
- bert-large-cased
- bert-large-uncased
- bert-large-uncased-whole-word-masking
- bert-large-cased-whole-word-masking

BERT 裡頭有 5 個特殊 tokens 各司其職：

- [CLS]：在做分類任務時其最後一層的 repr. 會被視為整個輸入序列的 repr.
- [SEP]：有兩個句子的文本會被串接成一個輸入序列，並在兩句之間插入這個 token 以做區隔
- [UNK]：沒出現在 BERT 字典裡頭的字會被這個 token 取代
- [PAD]：zero padding 遮罩，將長度不一的輸入序列補齊方便做 batch 運算
- [MASK]：未知遮罩，僅在預訓練階段會用到


# BERT fintune

https://zhuanlan.zhihu.com/p/62642374

https://leemeng.tw/attack_on_bert_transfer_learning_in_nlp.html