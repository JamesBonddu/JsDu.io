# Transformer的解释

http://jalammar.github.io/illustrated-transformer/

https://terrifyzhao.github.io/2019/01/11/Transformer%E6%A8%A1%E5%9E%8B%E8%AF%A6%E8%A7%A3.html

https://www.tensorflow.org/tutorials/text/transformer?hl=zh-cn

# BERT

https://blog.csdn.net/jiaowoshouzi/article/details/89073944

BERT的transformer网络结构学习到什么

Bert的Transformer低层学了表层特征，中间层学了句法特征，高层学了语义特征

https://easyai.tech/blog/what-does-bert-and-transformer-learn/

https://easyai.tech/ai-definition/


# Transformer模型深度解读起源发展

https://mp.weixin.qq.com/s/VHTiELTGTPXf3TURS6eXyw

query对应的是需要 「被表达」 的序列(称为序列A)，key和value对应的是 「用来表达」A的序列(称为序列B)。其中key和query是在同一高维空间中的(否则无法用来计算相似程度)，value不必在同一高维空间中，最终生成的output和value在同一高维空间中。上面这段巨绕的话用一句更绕的话来描述一下就是:

>❝
序列A和序列B在高维空间    中的高维表达  的每个位置 _「分别」 _ 和    计算相似度，产生的权重作用于序列B在高维空间  中的高维表达    ，获得序列A在高维空间  中的高维表达  ❞


Encoder部分中只存在self-attention，而Decoder部分中存在self-attention和cross-attention

【self-attention】encoder中的self-attention的query, key, value都对应了源端序列(即A和B是同一序列)，decoder中的self-attention的query, key, value都对应了目标端序列。

【cross-attention】decoder中的cross-attention的query对应了目标端序列，key, value对应了源端序列(每一层中的cross-attention用的都是encoder的最终输出)

- query(M*dqk)    和Key(N*dqk)      的维度必须一致，Value    和Query/Key的维度可以不一致。
- Key (N*dqk)   和Value(N*dv)    的长度必须一致.Key和Value本质上对应了同一个Sequence在不同空间的表达。


为什么要做multi-head attention？

也就是说，这样可以在不改变参数量的情况下增强每一层attention的表现力。 Multi-head Attention的本质是，在 「参数总量保持不变」 的情况下，将同样的query, key, value映射到原来的高维空间的「不同子空间」中进行attention的计算，在最后一步再合并不同子空间中的attention信息。这样降低了计算每个head的attention时每个向量的维度，在某种意义上防止了过拟合；

## <b>Transformer 资料汇总, 从概要到应用 </b>

https://mp.weixin.qq.com/s/_IZWOEtrcVcgLv1e2mkL6w

整体介绍

https://theaisummer.com/transformer/

自己实现einsum的多头注意的transforms

https://theaisummer.com/einsum-attention/

### einops

https://github.com/arogozhnikov/einops

### ACT adaptive-computation-time

https://distill.pub/2016/augmented-rnns/#adaptive-computation-time

# 安装

1. 先安装pytorch
2. 安装transformers

查看CUDA版本号
```sh
turing@ub:/opt$ cat  /usr/local/cuda/version.txt
CUDA Version 10.2.89
nvcc --version

# 参见
# https://pytorch.org/get-started/locally/#start-locally
# https://mirrors.tuna.tsinghua.edu.cn/help/pypi/
pip3  install torch torchvision torchaudio -i  https://pypi.douban.com/simple/

pip3 install transformers
```

https://blog.csdn.net/wcy23580/article/details/88723035