# 报错

```sh
File "/tmp/pip-build-fn9_nzes/pyarrow/setup.py", line 37, in <module>         from Cython.Distutils import build_ext as _build_ext     ModuleNotFoundError: No module named 'Cython'
```

解决:

pip3 install --upgrade cython

https://stackoverflow.com/questions/51608035/modulenotfounderror-no-module-named-cython-when-installing-pyarrow

https://stackoverflow.com/questions/43982543/importerror-no-module-named-cython

```sh
    -- Running cmake for pyarrow
    cmake -DPYTHON_EXECUTABLE=/usr/bin/python3 -DPython3_EXECUTABLE=/usr/bin/python3  -DPYARROW_BUILD_CUDA=off -DPYARROW_BUILD_FLIGHT=off -DPYARROW_BUILD_GANDIVA=off -DPYARROW_BUILD_DATASET=off -DPYARROW_BUILD_ORC=off -DPYARROW_BUILD_PARQUET=off -DPYARROW_BUILD_PLASMA=off -DPYARROW_BUILD_S3=off -DPYARROW_BUILD_HDFS=off -DPYARROW_USE_TENSORFLOW=off -DPYARROW_BUNDLE_ARROW_CPP=off -DPYARROW_BUNDLE_BOOST=off -DPYARROW_GENERATE_COVERAGE=off -DPYARROW_BOOST_USE_SHARED=on -DPYARROW_PARQUET_USE_SHARED=on -DCMAKE_BUILD_TYPE=release /tmp/pip-build-k_f64mkd/pyarrow
    -- The C compiler identification is GNU 7.5.0
    -- The CXX compiler identification is GNU 7.5.0
    -- Check for working C compiler: /usr/bin/cc
    -- Check for working C compiler: /usr/bin/cc -- works
    -- Detecting C compiler ABI info
    -- Detecting C compiler ABI info - done
    -- Detecting C compile features
    -- Detecting C compile features - done
    -- Check for working CXX compiler: /usr/bin/c++
    -- Check for working CXX compiler: /usr/bin/c++ -- works
    -- Detecting CXX compiler ABI info
    -- Detecting CXX compiler ABI info - done
    -- Detecting CXX compile features
    -- Detecting CXX compile features - done
    -- System processor: x86_64
    -- Performing Test CXX_SUPPORTS_SSE4_2
    -- Performing Test CXX_SUPPORTS_SSE4_2 - Success
    -- Performing Test CXX_SUPPORTS_AVX2
    -- Performing Test CXX_SUPPORTS_AVX2 - Success
    -- Performing Test CXX_SUPPORTS_AVX512
    -- Performing Test CXX_SUPPORTS_AVX512 - Success
    -- Arrow build warning level: PRODUCTION
    Using ld linker
    Configured for RELEASE build (set with cmake -DCMAKE_BUILD_TYPE={release,debug,...})
    -- Build Type: RELEASE
    -- Generator: Unix Makefiles
    -- Build output directory: /tmp/pip-build-k_f64mkd/pyarrow/build/temp.linux-x86_64-3.6/release
    -- Found PythonInterp: /usr/bin/python3 (found version "3.6.9")
    -- Searching for Python libs in /usr/lib64;/usr/lib;/usr/lib/python3.6/config-3.6m-x86_64-linux-gnu
    -- Looking for python3.6m
    -- Found Python lib /usr/lib/python3.6/config-3.6m-x86_64-linux-gnu/libpython3.6m.so
    -- Found PythonLibs: /usr/lib/python3.6/config-3.6m-x86_64-linux-gnu/libpython3.6m.so
    -- Found NumPy: version "1.19.5" /home/turing/.local/lib/python3.6/site-packages/numpy/core/include
    -- Found Python3Alt: /usr/bin/python3
    -- Searching for Python libs in /usr/lib64;/usr/lib;/usr/lib/python3.6/config-3.6m-x86_64-linux-gnu
    -- Looking for python3.6m
    -- Found Python lib /usr/lib/python3.6/config-3.6m-x86_64-linux-gnu/libpython3.6m.so
    -- Found PkgConfig: /usr/bin/pkg-config (found version "0.29.1")
    -- Could NOT find Arrow (missing: Arrow_DIR)
    -- Checking for module 'arrow'
    --   No package 'arrow' found
    CMake Error at /usr/share/cmake-3.10/Modules/FindPackageHandleStandardArgs.cmake:137 (message):
      Could NOT find Arrow (missing: ARROW_INCLUDE_DIR ARROW_LIB_DIR
      ARROW_FULL_SO_VERSION ARROW_SO_VERSION)
    Call Stack (most recent call first):
      /usr/share/cmake-3.10/Modules/FindPackageHandleStandardArgs.cmake:378 (_FPHSA_FAILURE_MESSAGE)
      cmake_modules/FindArrow.cmake:419 (find_package_handle_standard_args)
      cmake_modules/FindArrowPython.cmake:46 (find_package)
      CMakeLists.txt:214 (find_package)
    
    
    -- Configuring incomplete, errors occurred!
    See also "/tmp/pip-build-k_f64mkd/pyarrow/build/temp.linux-x86_64-3.6/CMakeFiles/CMakeOutput.log".
    error: command 'cmake' failed with exit status 1
    
    ----------------------------------------
Command "/usr/bin/python3 -u -c "import setuptools, tokenize;__file__='/tmp/pip-build-k_f64mkd/pyarrow/setup.py';f=getattr(tokenize, 'open', open)(__file__);code=f.read().replace('\r\n', '\n');f.close();exec(compile(code, __file__, 'exec'))" install --record /tmp/pip-7ik3t__2-record/install-record.txt --single-version-externally-managed --compile --user --prefix=" failed with error code 1 in /tmp/pip-build-k_f64mkd/pyarrow/

```

解决:

pip3 install --no-cache pyarrow==0.9.0

https://github.com/apache/arrow/issues/1125



```sh
TypeError: dropout(): argument 'input' (position 1) must be Tensor, not str
```
https://stackoverflow.com/questions/65082243/dropout-argument-input-position-1-must-be-tensor-not-str-when-using-bert